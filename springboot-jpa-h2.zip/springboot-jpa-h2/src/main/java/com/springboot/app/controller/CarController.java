package com.springboot.app.controller;

import com.springboot.app.exception.ResourceNotFoundException;
import com.springboot.app.model.Car;
import com.springboot.app.repository.CarRepository;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/v1")
@SuppressWarnings("unused")
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-02-10T23:27:00.079Z")
@Api(value = "cars", description = "the cars API")
public class CarController {

	@Autowired private CarRepository carRepository;

	@ApiOperation(value = "Lookup car by id", nickname = "getCarById", notes = "", tags = {"car"})
	@ApiResponses(value = {@ApiResponse(code = 200, message = "successful operation", response = Car.class, responseContainer = "List"), @ApiResponse(code = 400, message = "Invalid status value")})
	@GetMapping("/cars/{id}")
	public ResponseEntity<Car> getCarById(@ApiParam(value = "Id of the car", required = true) @PathVariable(value = "id") Long carId) throws ResourceNotFoundException {
		Car car = carRepository.findById(carId).orElseThrow(() -> new ResourceNotFoundException("Car not found for this id :: " + carId));
		return ResponseEntity.ok().body(car);
	}

	@ApiOperation(value = "Get all cars from the store", nickname = "getAllCars", notes = "", tags = {"car"})
	@ApiResponses(value = {@ApiResponse(code = 200, message = "successful operation", response = Car.class, responseContainer = "List"), @ApiResponse(code = 400, message = "Invalid status value")})
	@GetMapping("/cars")
	public List<Car> getCarById2(@ApiParam(value = "model of the car", required = true) @RequestParam(value = "model", required = false) String model, @ApiParam(value = "manufacturer of the car", required = true) @RequestParam(value = "manufacturer", required = false) String manufacturer) throws ResourceNotFoundException {
		if (model != null && manufacturer != null) {
			return carRepository.findCarByModelAndManufacturer(model, manufacturer).orElseThrow(() -> new ResourceNotFoundException("Car not found for the model " + model + " and manufacturer " + manufacturer));
		} else if (model != null) {
			return carRepository.findCarByModel(model).orElseThrow(() -> new ResourceNotFoundException("Car not found for the model " + model));
		} else if (manufacturer != null) {
			return carRepository.findCarByModel(manufacturer).orElseThrow(() -> new ResourceNotFoundException("Car not found for the manufacturer " + manufacturer));
		} else {
			return carRepository.findAll();
		}
	}

	@ApiOperation(value = "Add car details to the store", nickname = "createCar", notes = "", tags = {"car"})
	@ApiResponses(value = {@ApiResponse(code = 200, message = "successful operation", response = Car.class, responseContainer = "Car"), @ApiResponse(code = 400, message = "Invalid status value")})
	@PostMapping("/cars")
	public Car createCar(@Valid @RequestBody @ApiParam(value = "Create car that needs to be added to the store", required = true) Car car) {
		return carRepository.save(car);
	}

	@ApiOperation(value = "Update car details in the store", nickname = "updateCar", notes = "", tags = {"car"})
	@ApiResponses(value = {@ApiResponse(code = 200, message = "successful operation", response = Car.class, responseContainer = "Car"), @ApiResponse(code = 400, message = "Invalid status value")})
	@PutMapping("/cars/{id}")
	public ResponseEntity<Car> updateCar(@ApiParam(value = "Id of the car", required = true) @PathVariable(value = "id") Long carId, @ApiParam(value = "Updated car details", required = true) @Valid @RequestBody Car carDetails) throws ResourceNotFoundException {
		Car car = carRepository.findById(carId).orElseThrow(() -> new ResourceNotFoundException("Car not found for this id :: " + carId));
		car.setPrice(carDetails.getPrice());
		car.setManufacturer(carDetails.getManufacturer());
		car.setModel(carDetails.getModel());
		final Car updatedCar = carRepository.save(car);
		return ResponseEntity.ok(updatedCar);
	}

	@ApiOperation(value = "Delete car details from the store", nickname = "deleteCar", notes = "", tags = {"car"})
	@ApiResponses(value = {@ApiResponse(code = 200, message = "successful operation", response = Car.class, responseContainer = "Car"), @ApiResponse(code = 400, message = "Invalid status value")})
	@DeleteMapping("/cars/{id}")
	public Map<String, Boolean> deleteCar(@ApiParam(value = "car id that needs to be considered for deletion", required = true) @PathVariable(value = "id") Long carId) throws ResourceNotFoundException {
		Car car = carRepository.findById(carId).orElseThrow(() -> new ResourceNotFoundException("Car not found for this id :: " + carId));
		carRepository.delete(car);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
