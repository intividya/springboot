package com.springboot.app;

import com.springboot.app.model.Car;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class SpringRestClient {

	private static final String GET_CARS_ENDPOINT_URL = "http://localhost:8080/api/v1/cars";
	private static final String GET_CAR_ENDPOINT_URL = "http://localhost:8080/api/v1/cars/{id}";
	private static final String CREATE_CAR_ENDPOINT_URL = "http://localhost:8080/api/v1/cars";
	private static final String UPDATE_CAR_ENDPOINT_URL = "http://localhost:8080/api/v1/cars/{id}";
	private static final String DELETE_CAR_ENDPOINT_URL = "http://localhost:8080/api/v1/cars/{id}";
	private static final RestTemplate restTemplate = new RestTemplate();

	public static void main(String[] args) {
		SpringRestClient springRestClient = new SpringRestClient();

		// Step1: first create a new car
		springRestClient.createCar();

		// Step 2: get new created car from step1
		springRestClient.getCarById();

		// Step3: get all cars
		springRestClient.getCars();

		// Step4: Update car with id = 1
		springRestClient.updateCar();

		// Step5: Delete car with id = 1
		springRestClient.deleteCar();
	}

	private void getCars() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		ResponseEntity<String> result = restTemplate.exchange(GET_CARS_ENDPOINT_URL, HttpMethod.GET, entity, String.class);
		System.out.println(result);
	}

	private void getCarById() {
		Map<String, String> params = new HashMap<String, String>();
		params.put("id", "1");

		RestTemplate restTemplate = new RestTemplate();
		Car result = restTemplate.getForObject(GET_CAR_ENDPOINT_URL, Car.class, params);

		System.out.println(result);
	}

	private void createCar() {
		for (int i = 0; i < 100; i++) {
			Car newCar = new Car("C-Class-" + i, "Mercedes-Benz-" + i, 123123123d);
			RestTemplate restTemplate = new RestTemplate();
			Car result = restTemplate.postForObject(CREATE_CAR_ENDPOINT_URL, newCar, Car.class);
			System.out.println(result);
		}
	}

	private void updateCar() {
		Map<String, String> params = new HashMap<String, String>();
		params.put("id", "1");
		Car updatedCar = new Car("A Class", "Mercedes Benz", 1231235675d);
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.put(UPDATE_CAR_ENDPOINT_URL, updatedCar, params);
	}

	private void deleteCar() {
		Map<String, String> params = new HashMap<String, String>();
		params.put("id", "1");
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.delete(DELETE_CAR_ENDPOINT_URL, params);
	}
}
