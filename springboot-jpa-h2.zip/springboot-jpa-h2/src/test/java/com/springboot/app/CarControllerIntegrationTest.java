package com.springboot.app;

import com.springboot.app.model.Car;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class CarControllerIntegrationTest {

	@Autowired private TestRestTemplate restTemplate;

	@LocalServerPort private int port;

	private String getRootUrl() {
		return "http://localhost:" + port + "/api/v1";
	}

	@Test
	public void contextLoads() {

	}

	@Test
	public void testCreateCar() {
		Car car = new Car();
		car.setPrice(123123123d);
		car.setModel("test-model");
		car.setManufacturer("test-manufacturer");

		ResponseEntity<Car> postResponse = restTemplate.postForEntity(getRootUrl() + "/cars", car, Car.class);
		assertNotNull(postResponse);
		assertNotNull(postResponse.getBody());
	}

	@Test
	public void testGetAllCars() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<List> response = restTemplate.exchange(getRootUrl() + "/cars", HttpMethod.GET, entity, List.class);
		assertNotNull(response.getBody());
	}

	@Test
	public void testGetCarById() {
		Car car = restTemplate.getForObject(getRootUrl() + "/cars?model=test-model", Car.class);
		System.out.println(car.getModel());
		assertNotNull(car);
	}

	@Test
	public void testUpdateCar() {
//		testCreateCar();
		Car carList = restTemplate.getForObject(getRootUrl() + "/cars?model=test-model", Car.class);
		carList.setModel("abc");
		carList.setManufacturer("def");
		carList.setPrice(123123d);
		restTemplate.put(getRootUrl() + "/cars/" + carList.getId(), carList);
		Car updatedCar = restTemplate.getForObject(getRootUrl() + "/cars/" + carList.getId(), Car.class);
		assertNotNull(updatedCar);
	}

	@Test
	public void testDeleteCar() {
		Car car = restTemplate.getForObject(getRootUrl() + "/cars?model=test-model", Car.class);
		assertNotNull(car);
		restTemplate.delete(getRootUrl() + "/cars/" + car.getId());
		try {
			car = restTemplate.getForObject(getRootUrl() + "/cars/" + car.getId(), Car.class);
		} catch (final HttpClientErrorException e) {
			assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);
		}
	}
}
