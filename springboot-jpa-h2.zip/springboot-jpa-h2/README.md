### Build Instructions
```
mvn clean package
```
Compiles, runs unit tests and builds the jar binary of spring-boot app.

### Docker image build
```
docker build -t spring-boot/app:0.0.1 .
```

## Tech stack used
java 8
Spring Boot
Spring MVC
Spring Data
Spring Actuator
Docker

Note: For testing the service, please refer the test methods defined in src/main/java/com/springboot/app/SpringRestClient

### Launching service outside container
```
java -jar target\springboot2-jpa-crud-example-0.0.1.jar
```

or using maven command

```
mvn spring-boot:run
```

or using the docker run command

```
docker run -d -p 8080:8080 --name springboot-app spring-boot/app:0.0.1
```
```
curl -X GET http://localhost:8080/api/actuator/health
```
should return response as
```
{"status":"UP"}
```

### Swagger Documentation
Swagger documentation can be accessed through this link
```
http://localhost:8080/api/swagger-ui.html
```